<?php
function database()
{
	$conn=mysqli_connect("localhost","bouki","passer","sgbs");
	return $conn;
}

function lecture()
{
	$conn=database();
	$req="select * from telephone";
	$result=mysqli_query($conn,$req);
	$tab=mysqli_fetch_all($result,MYSQLI_ASSOC);
	return $tab;
}
$tab=lecture();
foreach($tab as $ligne)
{
	$prenom=$ligne[prenom];
	$nom=$ligne[nom];
	$nomfichier=$prenom.$nom.".gsm";
	echo "nous avons laissé un message dans le fichier $nomfichier";
	echo "   ";


}

?>

