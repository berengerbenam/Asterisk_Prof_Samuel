<?php
	echo "salut les amis";
?>


