<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8088/ari/channels?endpoint=Local/s@menu-IVR&extension=1000&context=ims&priority=1&timeout=30&api_key=asterisk:passer');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

$response = curl_exec($ch);

curl_close($ch);
?>

