<?php
$tel=$_REQUEST['tel'];
function database()
{
	$conn=mysqli_connect("localhost","bouki","passer","sgbs");
	return $conn;
}

function lecture($tel)
{
	$conn=database();
	$req="select * from telephone where tel='$tel'";
	$result=mysqli_query($conn,$req);
	$tab=mysqli_fetch_all($result,MYSQLI_ASSOC);
        $doit=$tab[0][credit];
        $message="Vous devez a la banque $doit";
	return $message;
}
$message=lecture($tel);
print_r($message);

?>

