<?php
function database()
{
	$conn=mysqli_connect("localhost","bouki","passer","sgbs");
	return $conn;
}

function lecture()
{
	$conn=database();
	$req="select * from telephone";
	$result=mysqli_query($conn,$req);
	$tab=mysqli_fetch_all($result,MYSQLI_ASSOC);
	return $tab;
}

function irilosi($tel)
{
       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, "http://localhost:8088/ari/channels?endpoint=Local/s@banque&extension=".$tel."&context=rtn&priority=1&timeout=30&api_key=asterisk:passer");
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_POST, 1);
       $result = curl_exec($ch);
        if (curl_errno($ch)) {
       echo 'Error:' . curl_error($ch);
                             }
       curl_close($ch);
}
$tab=lecture();
foreach($tab as $ligne)
{
	$tel=$ligne[tel];
        irilosi($tel);

}

?>

