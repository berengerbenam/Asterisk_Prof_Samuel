<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8088/ari/channels?endpoint=Local/s@banque&extension=1001&context=rtn&priority=1&timeout=30&api_key=asterisk:passer');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
?>
