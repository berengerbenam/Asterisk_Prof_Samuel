<?php
$tel=$_REQUEST['tel'];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://localhost:8088/ari/channels?endpoint=Local/s@second-ivr&extension=".$tel."&context=rtn&priority=1&timeout=30&api_key=asterisk:passer");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

$response = curl_exec($ch);

curl_close($ch);
?>

